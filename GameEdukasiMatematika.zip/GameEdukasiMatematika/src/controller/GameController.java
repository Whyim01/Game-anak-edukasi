package src.controller;

import src.model.Question;
import src.model.Difficulty;
import src.model.Player;
import src.util.QuestionGenerator;
import src.util.FileManager;

/**
 * Class GameController - Controller untuk game logic
 * Menerapkan konsep MVC Pattern dan Business Logic
 * 
 * @author Ahmad Husnul Fudoli
 */
public class GameController {
    private static final int TOTAL_QUESTIONS = 10;
    private static final int POINTS_PER_QUESTION = 10;
    
    private Difficulty currentDifficulty;
    private int currentQuestionNumber;
    private int score;
    private Question currentQuestion;
    private int timeRemaining;
    
    /**
     * Constructor
     */
    public GameController() {
        reset();
    }
    
    /**
     * Start game dengan difficulty tertentu
     * 
     * @param difficulty Tingkat kesulitan
     */
    public void startGame(Difficulty difficulty) {
        this.currentDifficulty = difficulty;
        this.currentQuestionNumber = 1;
        this.score = 0;
        this.timeRemaining = difficulty.getTimeLimit();
        generateNextQuestion();
    }
    
    /**
     * Generate soal berikutnya
     */
    public void generateNextQuestion() {
        currentQuestion = QuestionGenerator.generateQuestion(currentDifficulty);
    }
    
    /**
     * Check jawaban user
     * 
     * @param userAnswer Jawaban user
     * @return true jika benar
     */
    public boolean checkAnswer(int userAnswer) {
        boolean isCorrect = currentQuestion.checkAnswer(userAnswer);
        
        if (isCorrect) {
            score += POINTS_PER_QUESTION;
        }
        
        return isCorrect;
    }
    
    /**
     * Lanjut ke soal berikutnya
     * 
     * @return true jika masih ada soal
     */
    public boolean nextQuestion() {
        if (currentQuestionNumber < TOTAL_QUESTIONS) {
            currentQuestionNumber++;
            generateNextQuestion();
            return true;
        }
        return false;
    }
    
    /**
     * Check apakah game sudah selesai
     * 
     * @return true jika selesai
     */
    public boolean isGameOver() {
        return currentQuestionNumber > TOTAL_QUESTIONS || timeRemaining <= 0;
    }
    
    /**
     * Decrement waktu
     */
    public void decrementTime() {
        if (timeRemaining > 0) {
            timeRemaining--;
        }
    }
    
    /**
     * Save score ke leaderboard
     * 
     * @param playerName Nama pemain
     */
    public void saveScore(String playerName) {
        Player player = new Player(playerName, score, currentDifficulty.getDisplayName());
        FileManager.savePlayer(player);
    }
    
    /**
     * Get motivational message berdasarkan score
     * 
     * @return Pesan motivasi
     */
    public String getMotivationalMessage() {
        if (score >= 80) {
            return "Luar Biasa! Kamu jenius matematika! 🌟";
        } else if (score >= 60) {
            return "Bagus Sekali! Terus berlatih! 👍";
        } else if (score >= 40) {
            return "Lumayan! Kamu bisa lebih baik lagi! 😊";
        } else {
            return "Jangan menyerah! Coba lagi ya! 💪";
        }
    }
    
    /**
     * Reset game
     */
    public void reset() {
        currentDifficulty = null;
        currentQuestionNumber = 0;
        score = 0;
        currentQuestion = null;
        timeRemaining = 0;
    }
    
    // Getter methods
    public Difficulty getCurrentDifficulty() {
        return currentDifficulty;
    }
    
    public int getCurrentQuestionNumber() {
        return currentQuestionNumber;
    }
    
    public int getTotalQuestions() {
        return TOTAL_QUESTIONS;
    }
    
    public int getScore() {
        return score;
    }
    
    public Question getCurrentQuestion() {
        return currentQuestion;
    }
    
    public int getTimeRemaining() {
        return timeRemaining;
    }
}
