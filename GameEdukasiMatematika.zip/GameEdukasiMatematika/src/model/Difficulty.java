package src.model;

/**
 * Enum Difficulty - Merepresentasikan tingkat kesulitan
 * Menerapkan konsep Encapsulation dan Type Safety
 * 
 * @author Ahmad Husnul Fudoli
 */
public enum Difficulty {
    MUDAH("Mudah", 10, 30),
    SEDANG("Sedang", 50, 25),
    SULIT("Sulit", 100, 20);
    
    private final String displayName;
    private final int maxNumber;
    private final int timeLimit;
    
    /**
     * Constructor untuk Enum Difficulty
     * 
     * @param displayName Nama yang ditampilkan
     * @param maxNumber Angka maksimal untuk soal
     * @param timeLimit Waktu dalam detik
     */
    Difficulty(String displayName, int maxNumber, int timeLimit) {
        this.displayName = displayName;
        this.maxNumber = maxNumber;
        this.timeLimit = timeLimit;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    public int getMaxNumber() {
        return maxNumber;
    }
    
    public int getTimeLimit() {
        return timeLimit;
    }
    
    @Override
    public String toString() {
        return displayName;
    }
}
