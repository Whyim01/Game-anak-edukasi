package src.model;

/**
 * Class Question - Merepresentasikan soal matematika
 * Menerapkan konsep Encapsulation dengan private attributes dan public methods
 * 
 * @author Ahmad Husnul Fudoli
 */
public class Question {
    private int number1;
    private int number2;
    private String operator;
    private int correctAnswer;
    private String questionText;
    
    /**
     * Constructor untuk membuat objek Question
     * 
     * @param number1 Angka pertama
     * @param number2 Angka kedua
     * @param operator Operator matematika (+, -, x)
     */
    public Question(int number1, int number2, String operator) {
        this.number1 = number1;
        this.number2 = number2;
        this.operator = operator;
        calculateAnswer();
        generateQuestionText();
    }
    
    /**
     * Menghitung jawaban yang benar berdasarkan operator
     */
    private void calculateAnswer() {
        switch (operator) {
            case "+":
                correctAnswer = number1 + number2;
                break;
            case "-":
                correctAnswer = number1 - number2;
                break;
            case "x":
                correctAnswer = number1 * number2;
                break;
            default:
                correctAnswer = 0;
        }
    }
    
    /**
     * Generate text soal
     */
    private void generateQuestionText() {
        questionText = number1 + " " + operator + " " + number2 + " = ?";
    }
    
    /**
     * Validasi jawaban user
     * 
     * @param userAnswer Jawaban dari user
     * @return true jika benar, false jika salah
     */
    public boolean checkAnswer(int userAnswer) {
        return userAnswer == correctAnswer;
    }
    
    // Getter methods (Encapsulation)
    public int getNumber1() {
        return number1;
    }
    
    public int getNumber2() {
        return number2;
    }
    
    public String getOperator() {
        return operator;
    }
    
    public int getCorrectAnswer() {
        return correctAnswer;
    }
    
    public String getQuestionText() {
        return questionText;
    }
    
    @Override
    public String toString() {
        return questionText;
    }
}
