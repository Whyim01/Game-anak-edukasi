package src.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Class Player - Merepresentasikan pemain
 * Implements Serializable untuk menyimpan data ke file
 * 
 * @author Ahmad Husnul Fudoli
 */
public class Player implements Serializable, Comparable<Player> {
    private static final long serialVersionUID = 1L;
    
    private String name;
    private int score;
    private String difficulty;
    private String date;
    
    /**
     * Constructor untuk membuat objek Player
     * 
     * @param name Nama pemain
     * @param score Skor yang diperoleh
     * @param difficulty Tingkat kesulitan
     */
    public Player(String name, int score, String difficulty) {
        this.name = name;
        this.score = score;
        this.difficulty = difficulty;
        this.date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    }
    
    // Getter methods
    public String getName() {
        return name;
    }
    
    public int getScore() {
        return score;
    }
    
    public String getDifficulty() {
        return difficulty;
    }
    
    public String getDate() {
        return date;
    }
    
    // Setter methods
    public void setName(String name) {
        this.name = name;
    }
    
    public void setScore(int score) {
        this.score = score;
    }
    
    /**
     * CompareTo untuk sorting berdasarkan skor (descending)
     */
    @Override
    public int compareTo(Player other) {
        return Integer.compare(other.score, this.score); // Descending order
    }
    
    @Override
    public String toString() {
        return String.format("%s - %d poin (%s) - %s", name, score, difficulty, date);
    }
}
