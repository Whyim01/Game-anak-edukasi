package src.view;

import javax.swing.*;
import java.awt.*;

/**
 * Class MainFrame - Main window aplikasi
 * Menerapkan konsep Java Swing dan GUI Programming
 * 
 * @author Ahmad Husnul Fudoli
 */
public class MainFrame extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainPanel;
    
    // Panels
    private StartPanel startPanel;
    private GamePanel gamePanel;
    private ResultPanel resultPanel;
    private LeaderboardPanel leaderboardPanel;
    
    /**
     * Constructor
     */
    public MainFrame() {
        initComponents();
        setFrameProperties();
    }
    
    /**
     * Initialize components
     */
    private void initComponents() {
        // Setup CardLayout
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        
        // Create panels
        startPanel = new StartPanel(this);
        gamePanel = new GamePanel(this);
        resultPanel = new ResultPanel(this);
        leaderboardPanel = new LeaderboardPanel(this);
        
        // Add panels to CardLayout
        mainPanel.add(startPanel, "START");
        mainPanel.add(gamePanel, "GAME");
        mainPanel.add(resultPanel, "RESULT");
        mainPanel.add(leaderboardPanel, "LEADERBOARD");
        
        add(mainPanel);
    }
    
    /**
     * Set frame properties
     */
    private void setFrameProperties() {
        setTitle("🎮 Game Edukasi Matematika 🎮");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    /**
     * Show panel by name
     * 
     * @param panelName Nama panel
     */
    public void showPanel(String panelName) {
        cardLayout.show(mainPanel, panelName);
    }
    
    // Getter methods untuk panels
    public StartPanel getStartPanel() {
        return startPanel;
    }
    
    public GamePanel getGamePanel() {
        return gamePanel;
    }
    
    public ResultPanel getResultPanel() {
        return resultPanel;
    }
    
    public LeaderboardPanel getLeaderboardPanel() {
        return leaderboardPanel;
    }
}
