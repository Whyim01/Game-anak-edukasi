package src.view;

import src.controller.GameController;
import src.model.Difficulty;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Class ResultPanel - Panel untuk menampilkan hasil game
 * 
 * @author Ahmad Husnul Fudoli
 */
public class ResultPanel extends JPanel {
    private MainFrame mainFrame;
    private GameController gameController;
    
    private JLabel lblTitle, lblScore, lblMessage;
    private JTextField txtName;
    private JButton btnSave, btnPlayAgain, btnLeaderboard;
    
    private int finalScore;
    private Difficulty difficulty;
    
    /**
     * Constructor
     */
    public ResultPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        this.gameController = new GameController();
        initComponents();
    }
    
    /**
     * Initialize components
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(new Color(102, 126, 234));
        
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(new Color(102, 126, 234));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        
        lblTitle = new JLabel("🎉 PERMAINAN SELESAI! 🎉");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 32));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        lblScore = new JLabel("100 Poin");
        lblScore.setFont(new Font("Arial", Font.BOLD, 48));
        lblScore.setForeground(Color.YELLOW);
        lblScore.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        lblMessage = new JLabel("Bagus sekali!");
        lblMessage.setFont(new Font("Arial", Font.PLAIN, 20));
        lblMessage.setForeground(Color.WHITE);
        lblMessage.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Name input
        txtName = new JTextField();
        txtName.setFont(new Font("Arial", Font.PLAIN, 18));
        txtName.setHorizontalAlignment(JTextField.CENTER);
        txtName.setMaximumSize(new Dimension(400, 50));
        
        // Buttons
        btnSave = createButton("💾 Simpan Skor", new Color(74, 222, 128));
        btnPlayAgain = createButton("🔄 Main Lagi", new Color(102, 126, 234).brighter());
        btnLeaderboard = createButton("🏆 Lihat Papan Peringkat", new Color(251, 191, 36));
        
        // Add action listeners
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveScore();
            }
        });
        
        btnPlayAgain.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.showPanel("START");
            }
        });
        
        btnLeaderboard.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getLeaderboardPanel().refreshLeaderboard();
                mainFrame.showPanel("LEADERBOARD");
            }
        });
        
        // Add components
        centerPanel.add(lblTitle);
        centerPanel.add(Box.createVerticalStrut(20));
        centerPanel.add(lblScore);
        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(lblMessage);
        centerPanel.add(Box.createVerticalStrut(30));
        centerPanel.add(new JLabel("Masukkan Nama:") {{
            setForeground(Color.WHITE);
            setFont(new Font("Arial", Font.PLAIN, 16));
            setAlignmentX(Component.CENTER_ALIGNMENT);
        }});
        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(txtName);
        centerPanel.add(Box.createVerticalStrut(20));
        centerPanel.add(btnSave);
        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(btnPlayAgain);
        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(btnLeaderboard);
        
        add(centerPanel, BorderLayout.CENTER);
    }
    
    /**
     * Create button with style
     */
    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(400, 50));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
    
    /**
     * Show result
     */
    public void showResult(int score, String message, Difficulty difficulty) {
        this.finalScore = score;
        this.difficulty = difficulty;
        lblScore.setText(score + " Poin");
        lblMessage.setText(message);
        txtName.setText("");
    }
    
    /**
     * Save score to leaderboard
     */
    private void saveScore() {
        String name = txtName.getText().trim();
        
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Masukkan nama kamu dulu ya! 😊", 
                "Peringatan", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        gameController.startGame(difficulty);
        gameController.saveScore(name);
        
        JOptionPane.showMessageDialog(this, 
            "Skor berhasil disimpan! 🎉", 
            "Sukses", 
            JOptionPane.INFORMATION_MESSAGE);
        
        mainFrame.getLeaderboardPanel().refreshLeaderboard();
        mainFrame.showPanel("LEADERBOARD");
    }
}
