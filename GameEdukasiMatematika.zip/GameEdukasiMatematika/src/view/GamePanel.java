package src.view;

import src.controller.GameController;
import src.model.Difficulty;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Class GamePanel - Panel untuk gameplay
 * Menerapkan konsep Event Handling, Timer, dan Interactive UI
 * 
 * @author Ahmad Husnul Fudoli
 */
public class GamePanel extends JPanel {
    private MainFrame mainFrame;
    private GameController gameController;
    
    // UI Components
    private JLabel lblScore, lblTimer, lblQuestionNumber, lblQuestion, lblFeedback;
    private JTextField txtAnswer;
    private JButton btnSubmit;
    private Timer gameTimer;
    
    // Colors
    private final Color PRIMARY_COLOR = new Color(102, 126, 234);
    private final Color SECONDARY_COLOR = new Color(118, 75, 162);
    private final Color CORRECT_COLOR = new Color(74, 222, 128);
    private final Color WRONG_COLOR = new Color(248, 113, 113);
    
    /**
     * Constructor
     * 
     * @param mainFrame Reference ke main frame
     */
    public GamePanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        this.gameController = new GameController();
        initComponents();
        setupTimer();
    }
    
    /**
     * Initialize components
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        
        // Top Panel (Score and Timer)
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.WHITE);
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        
        lblScore = new JLabel("Skor: 0");
        lblScore.setFont(new Font("Arial", Font.BOLD, 20));
        lblScore.setForeground(PRIMARY_COLOR);
        
        lblTimer = new JLabel("⏰ Waktu: 30s");
        lblTimer.setFont(new Font("Arial", Font.BOLD, 20));
        lblTimer.setForeground(WRONG_COLOR);
        
        topPanel.add(lblScore, BorderLayout.WEST);
        topPanel.add(lblTimer, BorderLayout.EAST);
        
        // Center Panel (Question)
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(Color.WHITE);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        
        lblQuestionNumber = new JLabel("Soal 1 dari 10");
        lblQuestionNumber.setFont(new Font("Arial", Font.BOLD, 18));
        lblQuestionNumber.setForeground(Color.GRAY);
        lblQuestionNumber.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Question Card
        JPanel questionCard = new JPanel();
        questionCard.setLayout(new BorderLayout());
        questionCard.setBackground(PRIMARY_COLOR);
        questionCard.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));
        questionCard.setMaximumSize(new Dimension(600, 150));
        
        lblQuestion = new JLabel("5 + 3 = ?", SwingConstants.CENTER);
        lblQuestion.setFont(new Font("Arial", Font.BOLD, 48));
        lblQuestion.setForeground(Color.WHITE);
        questionCard.add(lblQuestion, BorderLayout.CENTER);
        
        // Answer input
        txtAnswer = new JTextField();
        txtAnswer.setFont(new Font("Arial", Font.PLAIN, 24));
        txtAnswer.setHorizontalAlignment(JTextField.CENTER);
        txtAnswer.setMaximumSize(new Dimension(400, 60));
        txtAnswer.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(PRIMARY_COLOR, 3),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // Submit button
        btnSubmit = new JButton("Kirim Jawaban ✓");
        btnSubmit.setFont(new Font("Arial", Font.BOLD, 20));
        btnSubmit.setBackground(PRIMARY_COLOR);
        btnSubmit.setForeground(Color.WHITE);
        btnSubmit.setFocusPainted(false);
        btnSubmit.setBorderPainted(false);
        btnSubmit.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnSubmit.setMaximumSize(new Dimension(400, 50));
        btnSubmit.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Feedback label
        lblFeedback = new JLabel(" ");
        lblFeedback.setFont(new Font("Arial", Font.BOLD, 24));
        lblFeedback.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Add components to center panel
        centerPanel.add(lblQuestionNumber);
        centerPanel.add(Box.createVerticalStrut(20));
        centerPanel.add(questionCard);
        centerPanel.add(Box.createVerticalStrut(30));
        centerPanel.add(txtAnswer);
        centerPanel.add(Box.createVerticalStrut(20));
        centerPanel.add(btnSubmit);
        centerPanel.add(Box.createVerticalStrut(20));
        centerPanel.add(lblFeedback);
        
        // Add action listeners
        btnSubmit.addActionListener(new SubmitButtonListener());
        txtAnswer.addActionListener(new SubmitButtonListener()); // Submit on Enter key
        
        add(topPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
    }
    
    /**
     * Setup game timer
     */
    private void setupTimer() {
        gameTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gameController.decrementTime();
                updateTimer();
                
                if (gameController.isGameOver()) {
                    endGame();
                }
            }
        });
    }
    
    /**
     * Start new game
     * 
     * @param difficulty Tingkat kesulitan
     */
    public void startNewGame(Difficulty difficulty) {
        gameController.startGame(difficulty);
        updateUI();
        txtAnswer.setText("");
        txtAnswer.setEnabled(true);
        btnSubmit.setEnabled(true);
        lblFeedback.setText(" ");
        gameTimer.start();
        txtAnswer.requestFocus();
    }
    
    /**
     * Update UI with current game state
     */
    private void updateUI() {
        lblScore.setText("Skor: " + gameController.getScore());
        updateTimer();
        lblQuestionNumber.setText("Soal " + gameController.getCurrentQuestionNumber() + 
                                  " dari " + gameController.getTotalQuestions());
        lblQuestion.setText(gameController.getCurrentQuestion().getQuestionText());
    }
    
    /**
     * Update timer label
     */
    private void updateTimer() {
        lblTimer.setText("⏰ Waktu: " + gameController.getTimeRemaining() + "s");
    }
    
    /**
     * Handle answer submission
     */
    private void handleSubmit() {
        try {
            int userAnswer = Integer.parseInt(txtAnswer.getText().trim());
            boolean isCorrect = gameController.checkAnswer(userAnswer);
            
            showFeedback(isCorrect);
            
            // Wait 1.5 seconds then next question or end game
            Timer feedbackTimer = new Timer(1500, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (gameController.nextQuestion()) {
                        updateUI();
                        txtAnswer.setText("");
                        lblFeedback.setText(" ");
                        txtAnswer.requestFocus();
                    } else {
                        endGame();
                    }
                    ((Timer)e.getSource()).stop();
                }
            });
            feedbackTimer.setRepeats(false);
            feedbackTimer.start();
            
        } catch (NumberFormatException ex) {
            lblFeedback.setText("⚠️ Masukkan angka!");
            lblFeedback.setForeground(WRONG_COLOR);
        }
    }
    
    /**
     * Show feedback for answer
     * 
     * @param isCorrect Whether answer is correct
     */
    private void showFeedback(boolean isCorrect) {
        if (isCorrect) {
            lblFeedback.setText("✓ Benar! Hebat!");
            lblFeedback.setForeground(CORRECT_COLOR);
            lblScore.setText("Skor: " + gameController.getScore());
        } else {
            lblFeedback.setText("✗ Salah! Jawaban: " + 
                              gameController.getCurrentQuestion().getCorrectAnswer());
            lblFeedback.setForeground(WRONG_COLOR);
        }
    }
    
    /**
     * End game and show result
     */
    private void endGame() {
        gameTimer.stop();
        txtAnswer.setEnabled(false);
        btnSubmit.setEnabled(false);
        
        mainFrame.getResultPanel().showResult(
            gameController.getScore(),
            gameController.getMotivationalMessage(),
            gameController.getCurrentDifficulty()
        );
        mainFrame.showPanel("RESULT");
    }
    
    /**
     * Inner class untuk handle submit button
     */
    private class SubmitButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            handleSubmit();
        }
    }
}
