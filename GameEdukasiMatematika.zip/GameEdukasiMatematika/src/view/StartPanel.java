package src.view;

import src.model.Difficulty;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Class StartPanel - Panel untuk start screen
 * Menerapkan konsep Event Handling dan GUI Design
 * 
 * @author Ahmad Husnul Fudoli
 */
public class StartPanel extends JPanel {
    private MainFrame mainFrame;
    private JButton btnMudah, btnSedang, btnSulit, btnLeaderboard;
    
    /**
     * Constructor
     * 
     * @param mainFrame Reference ke main frame
     */
    public StartPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        initComponents();
    }
    
    /**
     * Initialize components
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(new Color(102, 126, 234));
        
        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(102, 126, 234));
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        
        JLabel lblTitle = new JLabel("🎮 KUIS MATEMATIKA 🎮");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 36));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel lblSubtitle = new JLabel("Pilih Tingkat Kesulitan:");
        lblSubtitle.setFont(new Font("Arial", Font.PLAIN, 20));
        lblSubtitle.setForeground(Color.WHITE);
        lblSubtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        titlePanel.add(Box.createVerticalStrut(80));
        titlePanel.add(lblTitle);
        titlePanel.add(Box.createVerticalStrut(20));
        titlePanel.add(lblSubtitle);
        
        // Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(102, 126, 234));
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        
        // Create buttons
        btnMudah = createDifficultyButton("😊 MUDAH (1-10)", new Color(74, 222, 128));
        btnSedang = createDifficultyButton("🤔 SEDANG (1-50)", new Color(251, 191, 36));
        btnSulit = createDifficultyButton("😤 SULIT (1-100)", new Color(248, 113, 113));
        btnLeaderboard = createDifficultyButton("🏆 LEADERBOARD", new Color(168, 85, 247));
        
        // Add action listeners
        btnMudah.addActionListener(new DifficultyButtonListener(Difficulty.MUDAH));
        btnSedang.addActionListener(new DifficultyButtonListener(Difficulty.SEDANG));
        btnSulit.addActionListener(new DifficultyButtonListener(Difficulty.SULIT));
        btnLeaderboard.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.getLeaderboardPanel().refreshLeaderboard();
                mainFrame.showPanel("LEADERBOARD");
            }
        });
        
        buttonPanel.add(Box.createVerticalStrut(30));
        buttonPanel.add(btnMudah);
        buttonPanel.add(Box.createVerticalStrut(15));
        buttonPanel.add(btnSedang);
        buttonPanel.add(Box.createVerticalStrut(15));
        buttonPanel.add(btnSulit);
        buttonPanel.add(Box.createVerticalStrut(30));
        buttonPanel.add(btnLeaderboard);
        
        add(titlePanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
    }
    
    /**
     * Create difficulty button
     * 
     * @param text Button text
     * @param color Button color
     * @return JButton
     */
    private JButton createDifficultyButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 18));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(400, 60));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    /**
     * Inner class untuk handle difficulty button click
     */
    private class DifficultyButtonListener implements ActionListener {
        private Difficulty difficulty;
        
        public DifficultyButtonListener(Difficulty difficulty) {
            this.difficulty = difficulty;
        }
        
        @Override
        public void actionPerformed(ActionEvent e) {
            mainFrame.getGamePanel().startNewGame(difficulty);
            mainFrame.showPanel("GAME");
        }
    }
}
