package src.view;

import src.model.Player;
import src.util.FileManager;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * Class LeaderboardPanel - Panel untuk menampilkan leaderboard
 * 
 * @author Ahmad Husnul Fudoli
 */
public class LeaderboardPanel extends JPanel {
    private MainFrame mainFrame;
    private JTable table;
    private DefaultTableModel tableModel;
    private JButton btnBack;
    
    /**
     * Constructor
     */
    public LeaderboardPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        initComponents();
    }
    
    /**
     * Initialize components
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        
        // Title Panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(102, 126, 234));
        titlePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel lblTitle = new JLabel("🏆 PAPAN PERINGKAT 🏆");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 32));
        lblTitle.setForeground(Color.WHITE);
        titlePanel.add(lblTitle);
        
        // Table
        String[] columnNames = {"Peringkat", "Nama", "Skor", "Tingkat", "Tanggal"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        table = new JTable(tableModel);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.setRowHeight(40);
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(102, 126, 234));
        table.getTableHeader().setForeground(Color.WHITE);
        table.setSelectionBackground(new Color(220, 220, 255));
        
        // Center align text in cells
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        
        // Custom renderer for ranking column
        table.getColumnModel().getColumn(0).setCellRenderer(new RankingCellRenderer());
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        
        btnBack = new JButton("⬅️ Kembali");
        btnBack.setFont(new Font("Arial", Font.BOLD, 16));
        btnBack.setBackground(new Color(102, 126, 234));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBorderPainted(false);
        btnBack.setPreferredSize(new Dimension(200, 50));
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btnBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.showPanel("START");
            }
        });
        
        buttonPanel.add(btnBack);
        
        add(titlePanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        refreshLeaderboard();
    }
    
    /**
     * Refresh leaderboard data
     */
    public void refreshLeaderboard() {
        // Clear table
        tableModel.setRowCount(0);
        
        // Load data
        List<Player> players = FileManager.loadLeaderboard();
        
        if (players.isEmpty()) {
            // Show empty message
            Object[] row = {"", "Belum ada data", "", "", ""};
            tableModel.addRow(row);
        } else {
            // Populate table
            for (int i = 0; i < players.size(); i++) {
                Player player = players.get(i);
                String rank = getRankEmoji(i + 1);
                Object[] row = {
                    rank,
                    player.getName(),
                    player.getScore() + " poin",
                    player.getDifficulty(),
                    player.getDate()
                };
                tableModel.addRow(row);
            }
        }
    }
    
    /**
     * Get rank emoji
     */
    private String getRankEmoji(int rank) {
        switch (rank) {
            case 1: return "🥇 #1";
            case 2: return "🥈 #2";
            case 3: return "🥉 #3";
            default: return "#" + rank;
        }
    }
    
    /**
     * Custom cell renderer for ranking column
     */
    private class RankingCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value,
                    isSelected, hasFocus, row, column);
            
            setHorizontalAlignment(JLabel.CENTER);
            setFont(new Font("Arial", Font.BOLD, 14));
            
            // Color for top 3
            if (row == 0) {
                c.setBackground(new Color(255, 215, 0, 100)); // Gold
            } else if (row == 1) {
                c.setBackground(new Color(192, 192, 192, 100)); // Silver
            } else if (row == 2) {
                c.setBackground(new Color(205, 127, 50, 100)); // Bronze
            } else if (!isSelected) {
                c.setBackground(Color.WHITE);
            }
            
            return c;
        }
    }
}
