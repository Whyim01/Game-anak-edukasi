package src;

import src.view.MainFrame;
import javax.swing.SwingUtilities;

/**
 * Main class - Entry point aplikasi Game Edukasi Matematika
 * 
 * @author Ahmad Husnul Fudoli
 * @version 1.0
 * @since 2026-02-14
 */
public class Main {
    public static void main(String[] args) {
        // Menjalankan aplikasi di Event Dispatch Thread
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                MainFrame frame = new MainFrame();
                frame.setVisible(true);
            }
        });
    }
}
