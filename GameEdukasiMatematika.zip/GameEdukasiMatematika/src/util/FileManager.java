package src.util;

import src.model.Player;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Class FileManager - Utility untuk file handling
 * Menerapkan konsep File I/O dan Exception Handling
 * 
 * @author Ahmad Husnul Fudoli
 */
public class FileManager {
    private static final String FILE_PATH = "data/leaderboard.dat";
    
    // Private constructor
    private FileManager() {
        throw new UnsupportedOperationException("Utility class");
    }
    
    /**
     * Menyimpan player ke leaderboard
     * 
     * @param player Objek Player yang akan disimpan
     */
    public static void savePlayer(Player player) {
        List<Player> players = loadLeaderboard();
        players.add(player);
        Collections.sort(players); // Sort berdasarkan score
        
        // Simpan hanya top 10
        if (players.size() > 10) {
            players = players.subList(0, 10);
        }
        
        saveLeaderboard(players);
    }
    
    /**
     * Load leaderboard dari file
     * 
     * @return List of Player
     */
    public static List<Player> loadLeaderboard() {
        List<Player> players = new ArrayList<>();
        File file = new File(FILE_PATH);
        
        if (!file.exists()) {
            return players;
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            players = (List<Player>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading leaderboard: " + e.getMessage());
        }
        
        return players;
    }
    
    /**
     * Save leaderboard ke file
     * 
     * @param players List of Player
     */
    private static void saveLeaderboard(List<Player> players) {
        File file = new File(FILE_PATH);
        file.getParentFile().mkdirs(); // Create directory if not exists
        
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(players);
        } catch (IOException e) {
            System.err.println("Error saving leaderboard: " + e.getMessage());
        }
    }
    
    /**
     * Clear leaderboard (untuk testing)
     */
    public static void clearLeaderboard() {
        File file = new File(FILE_PATH);
        if (file.exists()) {
            file.delete();
        }
    }
}
