package src.util;

import src.model.Question;
import src.model.Difficulty;
import java.util.Random;

/**
 * Class QuestionGenerator - Utility untuk generate soal random
 * Menerapkan konsep Utility Class (static methods)
 * 
 * @author Ahmad Husnul Fudoli
 */
public class QuestionGenerator {
    private static final String[] OPERATORS = {"+", "-", "x"};
    private static final Random random = new Random();
    
    // Private constructor untuk mencegah instantiation
    private QuestionGenerator() {
        throw new UnsupportedOperationException("Utility class");
    }
    
    /**
     * Generate soal random berdasarkan difficulty
     * 
     * @param difficulty Tingkat kesulitan
     * @return Objek Question
     */
    public static Question generateQuestion(Difficulty difficulty) {
        int maxNumber = difficulty.getMaxNumber();
        String operator = OPERATORS[random.nextInt(OPERATORS.length)];
        
        int num1 = random.nextInt(maxNumber) + 1;
        int num2 = random.nextInt(maxNumber) + 1;
        
        // Untuk pengurangan, pastikan hasil tidak negatif
        if (operator.equals("-") && num1 < num2) {
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }
        
        return new Question(num1, num2, operator);
    }
}
