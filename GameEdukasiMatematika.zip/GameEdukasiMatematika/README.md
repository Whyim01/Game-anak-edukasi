# Game Edukasi Matematika - Versi Java

Aplikasi game edukasi matematika interaktif berbasis Java Swing dengan implementasi konsep Pemrograman Berorientasi Objek (PBO).

## 👨‍💻 Informasi

- **Nama**: Ahmad Husnul Fudoli
- **NIM**: 24131310006
- **Mata Kuliah**: Pemrograman Berorientasi Objek (PBO)
- **Tanggal**: 14 Februari 2026

## 📋 Deskripsi

Game edukasi matematika yang dirancang untuk anak-anak dengan fitur:
- Kuis matematika interaktif (penjumlahan, pengurangan, perkalian)
- Tiga tingkat kesulitan (Mudah, Sedang, Sulit)
- Sistem skor dan timer
- Leaderboard dengan persistensi data
- GUI yang menarik dan user-friendly

## 🎯 Konsep OOP yang Diterapkan

### 1. **Encapsulation (Enkapsulasi)**
- Semua atribut class dideklarasikan `private`
- Akses melalui getter dan setter methods
- Contoh: `Player.java`, `Question.java`

### 2. **Inheritance (Pewarisan)**
- `JPanel` sebagai parent class untuk semua panel
- Contoh: `StartPanel extends JPanel`

### 3. **Polymorphism (Polimorfisme)**
- Method overriding: `toString()`, `compareTo()`
- Interface implementation: `Serializable`, `Comparable`, `ActionListener`

### 4. **Abstraction (Abstraksi)**
- Pemisahan antara interface dan implementation
- Contoh: Enum `Difficulty` sebagai abstraksi tingkat kesulitan

## 📁 Struktur Project

```
GameEdukasiMatematika/
├── src/
│   ├── Main.java                    # Entry point aplikasi
│   ├── model/                       # Model classes (Data)
│   │   ├── Player.java             # Class untuk pemain
│   │   ├── Question.java           # Class untuk soal
│   │   └── Difficulty.java         # Enum tingkat kesulitan
│   ├── controller/                  # Controller classes (Business Logic)
│   │   └── GameController.java     # Controller game logic
│   ├── view/                        # View classes (GUI)
│   │   ├── MainFrame.java          # Main window
│   │   ├── StartPanel.java         # Panel start screen
│   │   ├── GamePanel.java          # Panel gameplay
│   │   ├── ResultPanel.java        # Panel hasil
│   │   └── LeaderboardPanel.java   # Panel leaderboard
│   └── util/                        # Utility classes
│       ├── QuestionGenerator.java  # Generator soal
│       └── FileManager.java        # File I/O handler
└── data/
    └── leaderboard.dat              # File data leaderboard
```

## 🛠️ Cara Menjalankan

### Di NetBeans:
1. Buka NetBeans IDE
2. File → Open Project
3. Pilih folder `GameEdukasiMatematika`
4. Klik kanan project → Run

### Manual (Command Line):
```bash
# Compile
javac -d bin src/**/*.java src/*.java

# Run
java -cp bin src.Main
```

## 🎮 Cara Bermain

1. **Pilih Tingkat Kesulitan**
   - Mudah: Angka 1-10, waktu 30 detik
   - Sedang: Angka 1-50, waktu 25 detik
   - Sulit: Angka 1-100, waktu 20 detik

2. **Jawab 10 Soal Matematika**
   - Ketik jawaban di kotak input
   - Tekan Enter atau klik "Kirim Jawaban"
   - Setiap jawaban benar = 10 poin

3. **Simpan Skor**
   - Masukkan nama Anda
   - Skor akan tersimpan di leaderboard

4. **Lihat Leaderboard**
   - Top 10 pemain dengan skor tertinggi
   - Data tersimpan permanen di file

## 🔧 Fitur Teknis

### File I/O
- Serialization untuk menyimpan objek Player
- FileManager untuk read/write operations
- Persistensi data antar session

### GUI Components
- Java Swing untuk interface
- CardLayout untuk navigation
- Custom styling dengan Colors dan Fonts
- Event Handling untuk interaksi user

### Timer & Threading
- `javax.swing.Timer` untuk countdown
- Event-driven programming
- Non-blocking UI operations

### Collections & Sorting
- `ArrayList` untuk menyimpan players
- `Collections.sort()` dengan `Comparable`
- Automatic sorting berdasarkan skor

## 📚 Dependencies

- Java SE 8 atau lebih tinggi
- Java Swing (included in JDK)
- Tidak ada external library

## 🎨 Screenshots

### Start Screen
Menampilkan pilihan tingkat kesulitan dengan tombol berwarna-warni.

### Game Screen
Menampilkan soal matematika, input jawaban, skor, dan timer.

### Result Screen
Menampilkan skor akhir dengan pesan motivasi dan form input nama.

### Leaderboard
Menampilkan top 10 pemain dengan medal untuk 3 besar.

## 📖 Dokumentasi Kode

Setiap class dilengkapi dengan:
- Javadoc comments
- Inline comments untuk logika kompleks
- Clear variable naming
- Consistent code style

## 🚀 Pengembangan Lebih Lanjut

Fitur yang bisa ditambahkan:
- Operasi pembagian
- Mode multiplayer
- Sound effects
- Achievement system
- Adaptive difficulty
- Database integration (MySQL/PostgreSQL)

## 📄 Lisensi

Project ini dibuat untuk keperluan akademik.

## 👨‍🏫 Dosen Pembimbing

[Nama Dosen]

---

**© 2026 Ahmad Husnul Fudoli - Game Edukasi Matematika**
